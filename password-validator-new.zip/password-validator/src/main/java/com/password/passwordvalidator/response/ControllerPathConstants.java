package com.password.passwordvalidator.response;


/**
 * The Class ControllerPathConstants.
 */
public class ControllerPathConstants {

    /** The Constant VALIDATE_URL. */
    public static final String VALIDATE_URL = "/validate";

}
