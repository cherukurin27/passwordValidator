package com.password.passwordvalidator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.password.passwordvalidator.controller.ValidationController;
import com.password.passwordvalidator.response.ValidatePasswordResponse;

@SpringBootTest
class PasswordValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

	@Autowired
	ValidationController validationController;

	/**
	 * Test validate password minimum exact.
	 */
	@Test
	public void testValidatePasswordMinimumLength() {
		String password = "zawe4";// 5 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testValidatePasswordMaximumLength() {
		String password = "zawe24566789";// 12 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testValidatePasswordMoreThanMaximumLength() {
		String password = "zawe24566789t";// 13 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void testValidatePasswordLessthanMinLength() {
		String password = "zaw";// 3 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void testValidatePasswordCaptialLetters() {
		String password = "ZAWEBC";// 6 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void testValidatePasswordSequenceLetters() {
		String password = "foofoofoo1";// 6 characters
		ResponseEntity<ValidatePasswordResponse> response = validationController.validatePassword(password);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
}
